<template>
    <div style="width: 100%;overflow: hidden">
      <img src="../assets/image/home/main.jpg" style="width: 100%;">
    </div>
</template>

<script>
export default {

}
</script>

<style scoped>
</style>
